from contextlib import closing

import mysql.connector
from tkinter import messagebox

from compartido.configuracion import configuracion_db


class GestorConexiones:
    def __init__(self):
        self.conexion = None
        self.conexion_quirofanos = None
        self.conexion_preventivos = None

        try:
            self.conexion = mysql.connector.connect(
                **configuracion_db("DB_GESTION", autocommit=True)
            )
            self.conexion_quirofanos = mysql.connector.connect(
                **configuracion_db("DB_QUIROFANOS", autocommit=True)
            )
            self.conexion_preventivos = mysql.connector.connect(
                **configuracion_db("DB_PREVENTIVOS", autocommit=True)
            )
        except mysql.connector.Error as err:
            self.cerrar()
            raise RuntimeError(f"No se pudo conectar a la base de datos: {err}") from err
        except Exception:
            self.cerrar()
            raise

    def cerrar(self):
        for conexion in (
            self.conexion,
            self.conexion_quirofanos,
            self.conexion_preventivos,
        ):
            try:
                if conexion is not None:
                    conexion.close()
            except mysql.connector.Error:
                pass

        self.conexion = None
        self.conexion_quirofanos = None
        self.conexion_preventivos = None

    def close(self):
        self.cerrar()

    def _get_conexion(self, modulo="gestion"):
        if modulo == "gestion":
            return self.conexion

        if modulo == "quirofanos":
            return self.conexion_quirofanos

        if modulo == "preventivos":
            return self.conexion_preventivos

        raise ValueError(f"Modulo no reconocido: {modulo}")

    def _require_connection(self, modulo="gestion"):
        conexion = self._get_conexion(modulo)

        if conexion is None:
            raise RuntimeError(
                f"La conexion con la base de datos '{modulo}' no esta disponible."
            )
        if not conexion.is_connected():
            try:
                # Solo antes de una operacion nueva. Nunca repetir SQL enviado.
                conexion.reconnect(attempts=1, delay=0)
            except mysql.connector.Error as err:
                raise RuntimeError(
                    f"No se pudo recuperar la conexion con '{modulo}'."
                ) from err
            if not conexion.is_connected():
                raise RuntimeError(f"La conexion con '{modulo}' sigue cerrada.")

        return conexion

    def _execute_commit_modulo(self, modulo, sql, params=(), ok_message=None, parent=None):
        conexion = self._require_connection(modulo)

        with closing(conexion.cursor()) as cursor:
            try:
                cursor.execute(sql, params)
                conexion.commit()

                if ok_message:
                    messagebox.showinfo("Exito", ok_message, parent=parent)

                return cursor.lastrowid

            except mysql.connector.Error:
                conexion.rollback()
                raise

    def _fetchone_modulo(self, modulo, sql, params=()):
        conexion = self._require_connection(modulo)
        conexion.rollback()

        with closing(conexion.cursor()) as cursor:
            cursor.execute(sql, params)
            return cursor.fetchone()

    def _fetchall_modulo(self, modulo, sql, params=()):
        conexion = self._require_connection(modulo)
        conexion.rollback()

        with closing(conexion.cursor()) as cursor:
            cursor.execute(sql, params)
            return cursor.fetchall()

    def _column_exists(self, table_name, column_name, modulo="gestion"):
        rows = self._fetchall_modulo(
            modulo,
            f"SHOW COLUMNS FROM `{table_name}` LIKE %s",
            (column_name,),
        )
        return bool(rows)

    def _table_exists(self, table_name, modulo="gestion"):
        rows = self._fetchall_modulo(
            modulo,
            "SHOW TABLES LIKE %s",
            (table_name,),
        )
        return bool(rows)

    def _first_existing_column(self, table_name, candidates, modulo="gestion"):
        for col in candidates:
            if self._column_exists(table_name, col, modulo=modulo):
                return col
        return None

    def _resolve_column(self, table_name, candidates, required=False, modulo="gestion"):
        col = self._first_existing_column(table_name, candidates, modulo=modulo)

        if not col and required:
            raise ValueError(f"No se encontro columna valida en {table_name}: {candidates}")

        return col
