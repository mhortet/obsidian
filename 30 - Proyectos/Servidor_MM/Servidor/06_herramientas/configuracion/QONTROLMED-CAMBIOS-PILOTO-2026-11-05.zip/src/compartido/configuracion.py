import os
import ipaddress
from pathlib import Path

from dotenv import load_dotenv

from compartido.utils.resources import env_path, legacy_env_paths


REQUIRED_DB_VARS = (
    "DB_HOST",
    "DB_USER",
    "DB_GESTION",
    "DB_QUIROFANOS",
    "DB_PREVENTIVOS",
)


def cargar_entorno_db():
    ruta_env = env_path()

    if not ruta_env.exists():
        rutas_legacy = [ruta for ruta in legacy_env_paths() if ruta.exists()]
        aviso_legacy = ""
        if rutas_legacy:
            rutas_txt = "\n".join(str(ruta) for ruta in rutas_legacy)
            aviso_legacy = (
                "\n\nSe ha detectado configuracion en una ruta antigua:\n"
                f"{rutas_txt}\n\n"
                "Mueve su contenido manualmente a la ruta canonica y deja de usar la ruta antigua."
            )
        raise RuntimeError(
            "No se encontro el archivo de configuracion de base de datos.\n\n"
            f"Ruta canonica esperada:\n{ruta_env}"
            f"{aviso_legacy}\n\n"
            "Crea el archivo .env en la ruta indicada con las variables DB_HOST, DB_PORT, "
            "DB_USER, DB_PASSWORD, DB_GESTION, DB_QUIROFANOS y DB_PREVENTIVOS."
        )

    load_dotenv(ruta_env, override=True)

    faltantes = [nombre for nombre in REQUIRED_DB_VARS if not os.getenv(nombre)]
    if os.getenv("DB_PASSWORD") is None:
        faltantes.append("DB_PASSWORD")

    if faltantes:
        raise RuntimeError(
            "Faltan datos de conexion en el archivo .env:\n"
            + "\n".join(f"- {nombre}" for nombre in faltantes)
            + f"\n\nArchivo revisado:\n{ruta_env}"
        )


def _entero_db(nombre, predeterminado, maximo):
    try:
        valor = int(os.getenv(nombre, str(predeterminado)))
    except ValueError as err:
        raise RuntimeError(f"{nombre} debe ser un numero entero valido.") from err
    if not 1 <= valor <= maximo:
        raise RuntimeError(f"{nombre} debe estar entre 1 y {maximo}.")
    return valor


def opciones_transporte_db():
    """TLS verificado por defecto; excepcion explicita solo para loopback local."""
    modo_tls = os.getenv("DB_TLS_REQUIRED", "1")
    if modo_tls not in ("0", "1"):
        raise RuntimeError("DB_TLS_REQUIRED debe ser 0 o 1.")
    opciones = {
        "connection_timeout": _entero_db("DB_CONNECT_TIMEOUT", 5, 300),
        "read_timeout": _entero_db("DB_READ_TIMEOUT", 30, 3600),
        "write_timeout": _entero_db("DB_WRITE_TIMEOUT", 30, 3600),
        "allow_local_infile": False,
    }
    if modo_tls == "0":
        # No aceptar 'localhost' por nombre: su resolucion podria variar.
        try:
            local = ipaddress.ip_address(os.getenv("DB_HOST", "")).is_loopback
        except ValueError:
            local = False
        if not local:
            raise RuntimeError("La excepcion sin TLS solo permite una IP loopback.")
        opciones["ssl_disabled"] = True
        return opciones
    ruta = os.getenv("DB_SSL_CA", "").strip()
    if not ruta:
        raise RuntimeError("Falta DB_SSL_CA para verificar el certificado del servidor.")
    ca = Path(ruta).expanduser()
    if not ca.is_absolute():
        ca = env_path().parent / ca
    if not ca.is_file():
        raise RuntimeError("No se encontro el certificado CA configurado en DB_SSL_CA.")
    opciones.update({
        "ssl_disabled": False,
        "ssl_ca": str(ca.resolve()),
        "ssl_verify_cert": True,
        "ssl_verify_identity": True,
        "tls_versions": ["TLSv1.2", "TLSv1.3"],
    })
    return opciones


def configuracion_db(database_env, *, autocommit=False):
    cargar_entorno_db()

    config = {
        "host": os.getenv("DB_HOST"),
        "port": _entero_db("DB_PORT", 3306, 65535),
        "user": os.getenv("DB_USER"),
        "password": os.getenv("DB_PASSWORD", ""),
        "database": os.getenv(database_env),
        "use_pure": True,
        **opciones_transporte_db(),
    }

    if not config["database"]:
        raise RuntimeError(f"Falta la variable {database_env} en el archivo .env.")

    if autocommit:
        config["autocommit"] = True

    return config
