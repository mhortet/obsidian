import tkinter as tk
from tkinter import ttk, messagebox
from Compras.utils.ui_helpers import recargar_tree
from Compras.utils.ui_helpers import crear_botonera
from Compras.services.marcas_service import (
    guardar_marca,
    modificar_marca,
    borrar_marca,
    buscar_marca_por_id,
    listar_marcas,
)
from compartido.autorizacion import tiene_permiso
from compartido.utils.resources import apply_window_icon
from compartido.utils.window_manager import enfocar_ventana, obtener_ventana_unica, registrar_ventana_unica


def abrir_marcas(raiz, db):
    if not tiene_permiso(db, "gestion.marcas_editar"):
        messagebox.showerror(
            "Acceso denegado",
            "Tu usuario no tiene permiso para gestionar marcas.",
            parent=raiz,
        )
        return

    existente = obtener_ventana_unica(raiz, "gestion.marcas")
    if existente:
        enfocar_ventana(existente["window"])
        return existente["window"]

    win = tk.Toplevel(raiz)
    registrar_ventana_unica(raiz, "gestion.marcas", win)
    win.title("Mantenimiento de marcas")
    win.geometry("700x550")
    apply_window_icon(win)

    def set_entry(entry, valor):
        estado = entry.cget("state")
        entry.config(state="normal")
        entry.delete(0, tk.END)
        entry.insert(0, "" if valor is None else str(valor))
        entry.config(state=estado)

    def get_entry(entry):
        return entry.get().strip()

    def limpiar():
        set_entry(e_id, "")
        set_entry(e_descripcion, "")
        e_descripcion.focus_set()

    def cargar_en_formulario(valores):
        if not valores:
            return
        set_entry(e_id, valores[0])
        set_entry(e_descripcion, valores[1])

    def refrescar_tabla(filtro=""):
        datos = listar_marcas(db)
        recargar_tree(tree, datos, filtro)

    def nuevo():
        limpiar()

    def guardar():
        id_marca = get_entry(e_id)
        descripcion = get_entry(e_descripcion)
        try:
            guardar_marca(db, descripcion, id_marca=id_marca)
            refrescar_tabla(get_entry(e_buscar))
            limpiar()
        except ValueError as e:
            messagebox.showwarning("Aviso", str(e))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def modificar():
        id_marca = get_entry(e_id)
        descripcion = get_entry(e_descripcion)

        try:
            modificar_marca(db, id_marca, descripcion)
            refrescar_tabla(get_entry(e_buscar))
        except ValueError as e:
            messagebox.showwarning("Aviso", str(e))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def borrar():
        id_marca = get_entry(e_id)
        if not id_marca:
            messagebox.showwarning("Aviso", "Selecciona una marca")
            return

        ok = messagebox.askyesno("Confirmar", f"¿Seguro que quieres borrar la marca {id_marca}?")
        if not ok:
            return

        try:
            borrar_marca(db, id_marca)
            refrescar_tabla(get_entry(e_buscar))
            limpiar()
        except ValueError as e:
            messagebox.showwarning("Aviso", str(e))
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def buscar_por_id():
        id_marca = get_entry(e_id)

        try:
            datos = buscar_marca_por_id(db, id_marca)
            if not datos:
                messagebox.showinfo("Info", "No se encontró la marca")
                return
            cargar_en_formulario(datos)
        except ValueError as e:
            messagebox.showwarning("Aviso", str(e))
        except Exception as e:
            messagebox.showerror("Error", str(e))
            
    def al_seleccionar(_event=None):
        item = tree.focus()
        if not item:
            return
        valores = tree.item(item, "values")
        cargar_en_formulario(valores)

    frame_form = tk.LabelFrame(win, text="Marca", padx=10, pady=10)
    frame_form.pack(fill="x", padx=10, pady=10)

    tk.Label(frame_form, text="ID").grid(row=0, column=0, sticky="w")
    tk.Label(frame_form, text="Descripción").grid(row=0, column=2, sticky="w")

    e_id = tk.Entry(frame_form, width=10)
    e_descripcion = tk.Entry(frame_form, width=40)

    e_id.grid(row=0, column=1, padx=5, pady=5, sticky="w")
    e_descripcion.grid(row=0, column=3, padx=5, pady=5, sticky="w")

    crear_botonera(win, [
        {"texto": "Nuevo", "comando": nuevo},
        {"texto": "Guardar", "comando": guardar},
        {"texto": "Modificar", "comando": modificar},
        {"texto": "Borrar", "comando": borrar},
        {"texto": "Buscar ID", "comando": buscar_por_id},
        {"texto": "Cerrar", "comando": win.destroy, "side": "right"},
    ])

    frame_lista = tk.LabelFrame(win, text="Listado", padx=10, pady=10)
    frame_lista.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    top_lista = tk.Frame(frame_lista)
    top_lista.pack(fill="x", pady=(0, 8))

    tk.Label(top_lista, text="Buscar").pack(side="left")
    e_buscar = tk.Entry(top_lista, width=40)
    e_buscar.pack(side="left", padx=5)

    cols = ("id", "descripcion")

    ################################
    # Scroll bar
    ################################
    frame_tree = tk.Frame(frame_lista)
    frame_tree.pack(fill="both", expand=True)

    scroll_y = tk.Scrollbar(frame_tree, orient="vertical")
    scroll_y.pack(side="right", fill="y")

    tree = ttk.Treeview(
        frame_tree,
        columns=cols,
        show="headings",
        yscrollcommand=scroll_y.set
    )
    tree.pack(side="left", fill="both", expand=True)
    scroll_y.config(command=tree.yview)
    #######################################################

    tree.heading("id", text="ID")
    tree.heading("descripcion", text="Descripción")

    tree.column("id", width=80, anchor="center")
    tree.column("descripcion", width=350, anchor="w")

    e_buscar.bind("<KeyRelease>", lambda e: refrescar_tabla(get_entry(e_buscar)))
    tree.bind("<<TreeviewSelect>>", al_seleccionar)
    tree.bind("<Double-1>", al_seleccionar)

    refrescar_tabla()
    limpiar()
