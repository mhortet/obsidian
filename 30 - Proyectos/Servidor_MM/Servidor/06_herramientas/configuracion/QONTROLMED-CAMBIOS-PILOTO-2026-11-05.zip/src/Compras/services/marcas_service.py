from Compras import db as compras_db
from mysql.connector import IntegrityError


def validar_descripcion_marca(descripcion):
    descripcion = (descripcion or "").strip()
    if not descripcion:
        raise ValueError("La marca es obligatoria")
    return descripcion


def guardar_marca(db, descripcion, *, id_marca=None):
    descripcion = validar_descripcion_marca(descripcion)
    id_texto = str(id_marca).strip() if id_marca is not None else ""
    if not id_texto.isascii() or not id_texto.isdecimal():
        raise ValueError("Introduce un ID de marca entero positivo.")
    id_numero = int(id_texto)
    if not 1 <= id_numero <= 2147483647:
        raise ValueError("El ID de marca debe estar entre 1 y 2147483647.")
    try:
        compras_db.execute(
            db,
            "INSERT INTO marcas (idMarcas, Descripcion) VALUES (%s, %s)",
            (id_numero, descripcion),
            ok_message="Marca guardada correctamente",
        )
    except IntegrityError as err:
        if err.errno == 1062:
            raise ValueError("Ya existe una marca con ese ID o esa descripcion.") from err
        raise


def modificar_marca(db, id_marca, descripcion):
    id_marca = (id_marca or "").strip()
    if not id_marca:
        raise ValueError("Selecciona una marca")

    descripcion = validar_descripcion_marca(descripcion)
    compras_db.execute(
        db,
        "UPDATE marcas SET Descripcion = %s WHERE idMarcas = %s;",
        (descripcion, id_marca),
        ok_message="Marca modificada correctamente",
    )


def borrar_marca(db, id_marca):
    id_marca = (id_marca or "").strip()
    if not id_marca:
        raise ValueError("Selecciona una marca")
    compras_db.execute(
        db,
        "DELETE FROM marcas WHERE idMarcas = %s;",
        (int(id_marca),),
        ok_message="Marca eliminada correctamente",
    )


def buscar_marca_por_id(db, id_marca):
    id_marca = (id_marca or "").strip()
    if not id_marca:
        raise ValueError("Introduce un ID")
    return compras_db.fetchone(
        db,
        "SELECT * FROM marcas WHERE idMarcas = %s;",
        (id_marca,),
    )


def listar_marcas(db):
    return compras_db.fetchall(db, "SELECT * FROM marcas;")
