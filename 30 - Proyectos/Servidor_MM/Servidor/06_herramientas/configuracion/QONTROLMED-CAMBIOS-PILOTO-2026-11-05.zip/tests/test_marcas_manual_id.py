import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
from mysql.connector import IntegrityError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from Compras.services.marcas_service import guardar_marca


class ManualBrandIdTests(unittest.TestCase):
    @patch('Compras.services.marcas_service.compras_db.execute')
    def test_explicit_imported_identifier_is_preserved(self, execute):
        db = Mock()
        guardar_marca(db, ' Marca ficticia ', id_marca=' 1207 ')
        self.assertEqual(execute.call_args.args, (
            db, 'INSERT INTO marcas (idMarcas, Descripcion) VALUES (%s, %s)',
            (1207, 'Marca ficticia'),
        ))

    @patch('Compras.services.marcas_service.compras_db.execute')
    def test_invalid_or_missing_identifier_never_writes(self, execute):
        for value in (None, '', 'abc', '-1', '0', '1.5', '2147483648', '１２'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                guardar_marca(Mock(), 'Marca ficticia', id_marca=value)
        execute.assert_not_called()

    @patch('Compras.services.marcas_service.compras_db.execute')
    def test_duplicate_is_reported_without_changing_existing_record(self, execute):
        execute.side_effect = IntegrityError('duplicate', errno=1062)
        with self.assertRaisesRegex(ValueError, 'Ya existe'):
            guardar_marca(Mock(), 'Marca ficticia', id_marca='1207')
        execute.assert_called_once()


if __name__ == '__main__':
    unittest.main()
