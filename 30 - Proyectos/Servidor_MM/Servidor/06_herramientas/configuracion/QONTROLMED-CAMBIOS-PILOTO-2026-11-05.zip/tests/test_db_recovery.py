import sys
import unittest
from pathlib import Path
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import mysql.connector
from compartido.db import GestorConexiones


class RecoveryTests(unittest.TestCase):
    def manager(self, connection):
        manager = GestorConexiones.__new__(GestorConexiones)
        manager.conexion = connection
        manager.conexion_quirofanos = None
        manager.conexion_preventivos = None
        return manager

    def test_closed_session_recovers_before_new_operation(self):
        connection = Mock()
        connection.is_connected.side_effect = [False, True]
        self.assertIs(self.manager(connection)._require_connection(), connection)
        connection.reconnect.assert_called_once_with(attempts=1, delay=0)

    def test_failed_recovery_is_bounded_and_does_not_execute_sql(self):
        connection = Mock()
        connection.is_connected.return_value = False
        connection.reconnect.side_effect = mysql.connector.InterfaceError("offline")
        with self.assertRaises(RuntimeError):
            self.manager(connection)._require_connection()
        connection.reconnect.assert_called_once()
        connection.cursor.assert_not_called()

    def test_write_failure_is_never_repeated(self):
        connection = Mock()
        connection.is_connected.return_value = True
        cursor = connection.cursor.return_value
        cursor.execute.side_effect = mysql.connector.OperationalError("lost connection")
        with self.assertRaises(mysql.connector.OperationalError):
            self.manager(connection)._execute_commit_modulo("gestion", "INSERT INTO ficticia VALUES (1)")
        cursor.execute.assert_called_once()
        connection.reconnect.assert_not_called()
        connection.rollback.assert_called_once()

    def test_close_also_closes_disconnected_session_and_is_idempotent(self):
        connection = Mock()
        manager = self.manager(connection)
        manager.cerrar()
        manager.cerrar()
        connection.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
