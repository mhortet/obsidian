import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from compartido.configuracion import configuracion_db, opciones_transporte_db


class TransportPolicyTests(unittest.TestCase):
    def test_missing_ca_fails_closed(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "DB_SSL_CA"):
                opciones_transporte_db()

    def test_verified_tls_and_finite_timeouts(self):
        with tempfile.TemporaryDirectory() as directory:
            ca = Path(directory) / "ca.pem"
            ca.write_text("public certificate fixture", encoding="utf-8")
            with patch.dict(os.environ, {"DB_SSL_CA": str(ca)}, clear=True):
                result = opciones_transporte_db()
        self.assertTrue(result["ssl_verify_cert"])
        self.assertTrue(result["ssl_verify_identity"])
        self.assertFalse(result["ssl_disabled"])
        self.assertFalse(result["allow_local_infile"])
        self.assertEqual(result["tls_versions"], ["TLSv1.2", "TLSv1.3"])
        self.assertEqual(result["read_timeout"], 30)
        self.assertEqual(result["write_timeout"], 30)

    def test_insecure_exception_never_allows_lan_or_names(self):
        for host in ("192.168.1.31", "localhost", "srv-mm-01", "", "example.com"):
            with self.subTest(host=host), patch.dict(os.environ, {
                "DB_HOST": host, "DB_TLS_REQUIRED": "0"
            }, clear=True):
                with self.assertRaises(RuntimeError):
                    opciones_transporte_db()

    def test_local_exception_is_explicit(self):
        with patch.dict(os.environ, {"DB_HOST": "127.0.0.1", "DB_TLS_REQUIRED": "0"}, clear=True):
            self.assertTrue(opciones_transporte_db()["ssl_disabled"])

    def test_relative_ca_uses_configuration_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            ca = Path(directory) / "ca.pem"
            ca.write_text("public certificate fixture", encoding="utf-8")
            with patch("compartido.configuracion.env_path", return_value=Path(directory) / ".env"), patch.dict(
                os.environ, {"DB_SSL_CA": "ca.pem"}, clear=True
            ):
                self.assertEqual(opciones_transporte_db()["ssl_ca"], str(ca.resolve()))

    def test_missing_ca_file_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(
            os.environ, {"DB_SSL_CA": str(Path(directory) / "missing.pem")}, clear=True
        ):
            with self.assertRaisesRegex(RuntimeError, "DB_SSL_CA"):
                opciones_transporte_db()

    def test_invalid_timeout_or_policy_rejected(self):
        for variable, value in (("DB_READ_TIMEOUT", "0"), ("DB_WRITE_TIMEOUT", "-1"),
                                ("DB_CONNECT_TIMEOUT", "bad"), ("DB_TLS_REQUIRED", "false")):
            with self.subTest(variable=variable), patch.dict(os.environ, {
                "DB_HOST": "127.0.0.1", "DB_TLS_REQUIRED": "0", variable: value
            }, clear=True):
                with self.assertRaises(RuntimeError):
                    opciones_transporte_db()

    def test_port_bounds_and_no_real_environment_file_loaded(self):
        for port in ("0", "65536", "invalid"):
            with self.subTest(port=port), patch("compartido.configuracion.cargar_entorno_db"), patch.dict(
                os.environ, {"DB_HOST": "127.0.0.1", "DB_TLS_REQUIRED": "0", "DB_PORT": port}, clear=True
            ):
                with self.assertRaisesRegex(RuntimeError, "DB_PORT"):
                    configuracion_db("DB_GESTION")


if __name__ == "__main__":
    unittest.main()
